
#include "RandomWalkDungeonGenerator.h"
#include "Vector2iHash.h"

#include "ProceduralGenerationAlgorithms.h"
#include "Random.h"


RandomWalkDungeonGenerator::RandomWalkDungeonGenerator() {
    std::unordered_set<sf::Vector2i> floorPositions = runRandomWalk();
}

void RandomWalkDungeonGenerator::runProceduralGeneration() {
    sf::Vector2i currentPostion = startPosition;
    for (int i = 0; i < iterations; i++) {
        std::unordered_set<sf::Vector2i> path = ProceduralGenerationAlgorithms::simpleRandomWalk(currentPostion, walkLength);
        floorPositions.insert(path.begin(), path.end());
        if(startRandomlyEachIteration) {
            currentPostion = Random<sf::Vector2i>::getRandomElement(floorPositions);
        }
    }
}

