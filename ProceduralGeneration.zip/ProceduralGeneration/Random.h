#pragma once
#include <unordered_set>

template <typename T>
class Random {
public:
    static T getRandomElementInRange(const std::unordered_set<T>& set, size_t startIndex, size_t endIndex);
    static T getRandomElement(const std::unordered_set<T>& set);
};
