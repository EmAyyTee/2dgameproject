#include "Vector2iHash.h"
#include <unordered_set>
#include <random>
#include <stdexcept>
#include <iterator>

template <typename T>
class Random {
public:
    static T getRandomElement(const std::unordered_set<T>& set) {
        if (set.empty()) {
            throw std::runtime_error("Cannot get a random element from an empty set");
        }

        static std::random_device rd;
        static std::mt19937 gen(rd());
        std::uniform_int_distribution<> dist(0, set.size() - 1);


        int randomIndex = dist(gen);

        auto it = set.begin();
        std::advance(it, randomIndex);

        return *it;
    }
};