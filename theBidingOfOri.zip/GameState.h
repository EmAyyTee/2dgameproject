#pragma once

enum class GameState{
    MainMenu = 0,
    Running = 1,
    Paused = 2,
    Quitting = 3,
    LevelUpScreen = 4
};