#pragma once

enum class GameState{
    MainMenu = 0,
    Running = 1
};