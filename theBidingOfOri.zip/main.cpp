#include "Engine.h"

#include "MainWindow.h"

int main(){
    MainWindow main_window;
    Engine engine(main_window);
    return 0;
}
