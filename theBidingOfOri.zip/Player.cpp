#include "Player.h"

#include <cmath>
#include <iostream>

#include "Animator.h"
#include "PlayerArrow.h"
#include "fmt/core.h"
#include "SFML/Window/Event.hpp"
#include "SFML/Window/Keyboard.hpp"


Player::Player(const sf::Vector2f& position, std::shared_ptr<std::map<std::string, std::vector<std::pair <int, sf::Texture>>>> playerTexturesPointer,
    sf::RenderWindow* renderTarget, std::map<std::string, sf::Keyboard::Key>* supportedKeys)
    : Character(position, renderTarget), playerTexturesPointer(std::move(playerTexturesPointer)), supportedKeys(supportedKeys), currentDamage(1){

    animation.calculateTheFrames(0, 0, 128, 74);
    animation.setNumberOfFrames(6);
    direction = {0.0f, 0.0f};
    playerState = PlayerState::PlayerIdle;

    Character::setHitbox(sf::Vector2f(128.0f, 74.0f), sf::Color::Blue, position,hitBox);
}

void Player::update(float deltaTime, std::vector<PlayerArrow> &arrows) {
    this -> arrows = &arrows;
    playerGetInput();
    Character::update(deltaTime);
    animation.Update(deltaTime, static_cast<int>(playerState), sprite, &playerTexturesPointer->at("playerTextures"));
}

void Player::playerGetInput() {

    direction = {0.0f, 0.0f};

    if(canAnimationCanChange()) {
        playerState = PlayerState::PlayerIdle;
    }

        if (sf::Keyboard::isKeyPressed(supportedKeys->at("walkUp"))) {
            direction.y -= 1.0f;
            if(canAnimationCanChange()) {
                playerState = PlayerState::PlayerWalkingRight;
            }
        }
        if (sf::Keyboard::isKeyPressed(supportedKeys->at("walkDown"))) {
            direction.y += 1.0f;
            if(canAnimationCanChange()) {
                playerState = PlayerState::PlayerWalkingRight;
            }
        }
        if (sf::Keyboard::isKeyPressed(supportedKeys->at("walkLeft"))) {
            direction.x -= 1.0f;
            if(canAnimationCanChange()) {
                playerState = PlayerState::PlayerWalkingLeft;
            }
        }
        if (sf::Keyboard::isKeyPressed(supportedKeys->at("walkRight"))) {
            direction.x += 1.0f;
            if(canAnimationCanChange()) {
                playerState = PlayerState::PlayerWalkingRight;
            }
        }
        if (sf::Mouse::isButtonPressed(sf::Mouse::Left ) && shotClock.getElapsedTime().asSeconds() > cooldownTimeForShootingAnArrow) {
            mousePosition = renderTarget->mapPixelToCoords(
           sf::Mouse::getPosition(*renderTarget)
       );
            std::cout << mousePosition.x << ", " << mousePosition.y << std::endl;
            arrows->push_back(PlayerArrow (position, mousePosition, &playerTexturesPointer->at("arrowTextures"), renderTarget, currentDamage));
            shotClock.restart();

            if(canAnimationCanChange()) {
                directionalVector = mousePosition - position;
                magnitude = sqrt(directionalVector.x * directionalVector.x + directionalVector.y * directionalVector.y);
                directionalVector = directionalVector /magnitude;

                if (playerState != PlayerState::PlayerShootingLeft || playerState != PlayerState::PlayerShootingRight) {
                    if (fabs(directionalVector.x) > fabs(directionalVector.y)) {
                        if (directionalVector.x > 0.0f) {
                            playerState = PlayerState::PlayerShootingRight;
                            animation.calculateTheFrames(0,3,64,64);
                        }
                        else {
                            playerState = PlayerState::PlayerShootingLeft;
                            animation.calculateTheFrames(0,2,64,64);
                        }
                    }
                    isAnimationPlaying = true;
                    animationClock.start();
                }
            }

            // Leaving the logic for when I have art for up and down
            // else {
            //     if (directionalVector.y > 0.0f) {
            //         playerState = PlayerState::PlayerShootingDown;
            //         animation.calculateTheFrames(0,0,64,64);
            //     }
            //     else {
            //         playerState = PlayerState::PlayerShootingUp;
            //         animation.calculateTheFrames(0,1,64,64);
            //     }
            // }

    }
}

bool Player::canAnimationCanChange() {
    if (isAnimationPlaying && animationClock.getClockTime().asSeconds() > 1.0f) {
        isAnimationPlaying = false;
        animationClock.restart();
        return false;
    }
    return true;
}


sf::Vector2f Player::getPosition() {
    return position;
}



